package com.javaxyq.data;

import java.io.Serializable;


public abstract class Items implements Serializable {

	private static final long serialVersionUID = 1L;
	public Long id;
	public String name;
	public String type;
	public String description;
	
	public Items(){
	}
	
	public Long getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
	
	public String getType(){
		return type;
	}
	
	public String getDescription(){
		return description;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setType(String type){
		this.type = type;
	}
	
	public void setDescription(String description){
		this.description = description;
	}
	
	public abstract String toString();
	
	public abstract int hashCode();

}
