package com.javaxyq.data;

import java.util.List;



public interface ItemDAO {

	public abstract void create(ItemInstance Item) throws PreexistingEntityException, MedicineItemException;

	public abstract void edit(ItemInstance Item) throws NonexistentEntityException, MedicineItemException;

	public abstract void destroy(Long id) throws NonexistentEntityException, MedicineItemException;

	public abstract List<ItemInstance> findItemEntities() throws MedicineItemException;

	public abstract List<ItemInstance> findItemEntities(int maxResults, int firstResult) throws MedicineItemException;

	public abstract ItemInstance findItem(Long id) throws MedicineItemException;

	public abstract int getItemCount() throws MedicineItemException;

	//************* custom *********************//
	public abstract ItemInstance findItemByName(String name) throws MedicineItemException;

	public abstract List<ItemInstance> findItemsByType(int type) throws MedicineItemException;

}